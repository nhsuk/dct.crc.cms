# Helm chart for the crc-web application

You will need the crc-web image locally. The best way to create it is to run:
```
docker build . -t crc-web
```

## Wagtail

Runs the HTTP server on port 8000 using uwsgi in front of wagtail.


## Initializer

A one-off job which runs startup tasks such as migrating the database.

## Redis

Redis cache, exposed with a service.

## Databases

There are two main types of database connection, `mssql` and `sqlite`
mssql is used in production so should be used where possible, sqlite is available
for working locally when a mssql container would be too slow.

When using sqlite, a PersistentVolume resource is required to share the database file between pods

To create a persistent volume, create the following yaml file:

```yaml
apiVersion: v1
kind: PersistentVolume
metadata:
  name: crc-web-volume-db
  labels:
    type: local
spec:
  storageClassName: manual
  capacity:
    storage: 100Mi
  accessModes:
    - ReadWriteOnce
  persistentVolumeReclaimPolicy: Recycle
  hostPath:
    path: "/tmp/crc-web-db"
```

Then run `kubectl apply -f your-file-name.yaml`

Run `kubectl get pv` to see your volumes.

## Asset Storage

Assets such as images and documents can be uploaded via the Wagtail CMS. In production, these assets are stored in
azure blob storage via the django-storages package.

In local development, you can run a blob storage emulator by setting a helm value of azureStorage.emulated=true.
An azure storage emulator will run on localhost on port 10000.

You will need another PersistentVolume resource, similar to the PV required by the sqlite database.

To create a persistent volume, create the following yaml file:

```yaml
apiVersion: v1
kind: PersistentVolume
metadata:
  name: crc-web-volume-assets
  labels:
    type: local
spec:
  storageClassName: manual
  capacity:
    storage: 100Mi
  accessModes:
    - ReadWriteOnce
  persistentVolumeReclaimPolicy: Recycle
  hostPath:
    path: "/tmp/crc-web-assets"
```

Then run `kubectl apply -f your-file-name.yaml`

Run `kubectl get pv` to see your volumes.
